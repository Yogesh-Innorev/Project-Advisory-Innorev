# GetAccount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**plan** | [**\Brevo\Client\Model\GetAccountPlan[]**](GetAccountPlan.md) | Information about your plans and credits | 
**relay** | [**\Brevo\Client\Model\GetAccountRelay**](GetAccountRelay.md) |  | 
**marketingAutomation** | [**\Brevo\Client\Model\GetAccountMarketingAutomation**](GetAccountMarketingAutomation.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)



# GetWhatsappCampaigns

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**campaigns** | [**\Brevo\Client\Model\GetWhatsappCampaignsCampaigns[]**](GetWhatsappCampaignsCampaigns.md) |  | [optional] 
**count** | **int** | Number of WhatsApp campaigns retrived | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)



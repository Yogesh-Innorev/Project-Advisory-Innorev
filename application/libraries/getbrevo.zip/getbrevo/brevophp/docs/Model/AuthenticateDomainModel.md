# AuthenticateDomainModel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**domainName** | **string** | Domain | 
**message** | **string** | Success message | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)



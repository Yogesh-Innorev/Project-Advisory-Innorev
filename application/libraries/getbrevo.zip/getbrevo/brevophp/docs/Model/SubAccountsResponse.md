# SubAccountsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** | Total number of subaccounts | [optional] 
**subAccounts** | [**\Brevo\Client\Model\SubAccountsResponseSubAccounts[]**](SubAccountsResponseSubAccounts.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)



# Body3

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** | Name of company | [optional] 
**attributes** | **object** | Attributes for company update | [optional] 
**countryCode** | **int** | Country code if phone_number is passed in attributes. | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)



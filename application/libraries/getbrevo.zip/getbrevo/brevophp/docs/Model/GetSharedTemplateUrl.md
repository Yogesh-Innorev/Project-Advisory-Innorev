# GetSharedTemplateUrl

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sharedUrl** | **string** | A unique URL for the email campaign or transactional template. This URL can be shared with other Brevo users. | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)



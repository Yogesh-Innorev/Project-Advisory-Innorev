# SubAccountDetailsResponsePlanInfoFeaturesLandingPage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**quantity** | **int** | Quantity of landing pages provided | [optional] 
**remaining** | **int** | Available landing pages for use | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)



# GetAccountActivity

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**logs** | [**\Brevo\Client\Model\GetAccountActivityLogs[]**](GetAccountActivityLogs.md) | Get user activity logs | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)



# GetSegmentsSegments

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | ID of the list | [optional] 
**segmentName** | **string** | Name of the Segment | [optional] 
**categoryName** | **string** | Name of the Segment Category | [optional] 
**updatedAt** | **string** | Updation UTC date-time of the segment (YYYY-MM-DDTHH:mm:ss.SSSZ) | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)



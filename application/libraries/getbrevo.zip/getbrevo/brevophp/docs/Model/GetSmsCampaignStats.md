# GetSmsCampaignStats

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**delivered** | **int** | Number of delivered SMS | 
**sent** | **int** | Number of sent SMS | 
**processing** | **int** | Number of processing SMS | 
**softBounces** | **int** | Number of softbounced SMS | 
**hardBounces** | **int** | Number of hardbounced SMS | 
**unsubscriptions** | **int** | Number of unsubscription SMS | 
**answered** | **int** | Number of replies to the SMS | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)



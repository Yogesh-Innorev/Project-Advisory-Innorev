# GetOrders

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**orders** | **object[]** |  | [optional] 
**count** | **int** | Number of orders | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)



# SubAccountDetailsResponsePlanInfoCredits

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sms** | **int** | SMS credits remaining on the sub-account | [optional] 
**emails** | [**\Brevo\Client\Model\SubAccountDetailsResponsePlanInfoCreditsEmails**](SubAccountDetailsResponsePlanInfoCreditsEmails.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)



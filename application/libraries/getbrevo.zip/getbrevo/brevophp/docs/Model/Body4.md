# Body4

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**linkContactIds** | **int[]** | Contact ids for contacts to be linked with company | [optional] 
**unlinkContactIds** | **int[]** | Contact ids for contacts to be unlinked from company | [optional] 
**linkDealsIds** | **string[]** | Deals ids for deals to be linked with company | [optional] 
**unlinkDealsIds** | **string[]** | Deals ids for deals to be unlinked from company | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)



# SubAccountUpdatePlanRequestFeatures

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**users** | **int** | Number of multi-users | [optional] 
**landingPage** | **int** | Number of landing pages / Not required on ENTv2 | [optional] 
**inbox** | **int** | Number of inboxes / Not required on ENTv2 | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)



# GetExtendedContactDetailsStatisticsMessagesSent

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**campaignId** | **int** | ID of the campaign which generated the event | 
**eventTime** | **string** | UTC date-time of the event | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)



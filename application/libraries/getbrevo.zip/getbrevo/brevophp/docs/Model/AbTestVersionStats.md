# AbTestVersionStats

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**versionA** | **string** | percentage of an event for version A | 
**versionB** | **string** | percentage of an event for version B | 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)



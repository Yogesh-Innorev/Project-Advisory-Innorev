# SubAccountDetailsResponsePlanInfoFeaturesUsers

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**quantity** | **int** | Quantity of multi-account&#39;s provided | [optional] 
**remaining** | **int** | Available multi-accounts for use | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)


